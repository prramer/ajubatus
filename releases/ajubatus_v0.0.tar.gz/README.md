ajubatus Readme

ajubatus is a program that automatically renames digital photographs according to a simple naming scheme.  Its name comes from the scientific name for the cheetah, which is A. jubatus.
